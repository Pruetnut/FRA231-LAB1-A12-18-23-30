/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: QEI_READ.h
 *
 * Code generated for Simulink model 'QEI_READ'.
 *
 * Model version                  : 1.3
 * Simulink Coder version         : 24.2 (R2024b) 21-Jun-2024
 * C/C++ source code generated on : Fri Nov  1 04:06:52 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef QEI_READ_h_
#define QEI_READ_h_
#ifndef QEI_READ_COMMON_INCLUDES_
#define QEI_READ_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_extmode.h"
#include "sysran_types.h"
#include "math.h"
#include "main.h"
#endif                                 /* QEI_READ_COMMON_INCLUDES_ */

#include "QEI_READ_types.h"
#include "MW_target_hardware_resources.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
#define rtmGetFinalTime(rtm)           ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWExtModeInfo
#define rtmGetRTWExtModeInfo(rtm)      ((rtm)->extModeInfo)
#endif

#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   ((rtm)->Timing.taskTime0)
#endif

#ifndef rtmGetTFinal
#define rtmGetTFinal(rtm)              ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                (&(rtm)->Timing.taskTime0)
#endif

/* Block signals for system '<S20>/Digital Port Read' */
typedef struct {
  boolean_T DigitalPortRead;           /* '<S20>/Digital Port Read' */
} B_DigitalPortRead_QEI_READ_T;

/* Block states (default storage) for system '<S20>/Digital Port Read' */
typedef struct {
  stm32cube_blocks_DigitalPortR_T obj; /* '<S20>/Digital Port Read' */
  boolean_T objisempty;                /* '<S20>/Digital Port Read' */
} DW_DigitalPortRead_QEI_READ_T;

/* Block signals (default storage) */
typedef struct {
  real_T CastToDouble5;                /* '<Root>/Cast To Double5' */
  real_T pulse;                        /* '<Root>/MATLAB Function9' */
  real_T angularPosition;              /* '<Root>/MATLAB Function9' */
  real_T angularVelocity;              /* '<Root>/MATLAB Function9' */
  real_T pulse_n;                      /* '<Root>/MATLAB Function8' */
  real_T angularPosition_o;            /* '<Root>/MATLAB Function8' */
  real_T angularVelocity_c;            /* '<Root>/MATLAB Function8' */
  real_T pulse_c;                      /* '<Root>/MATLAB Function7' */
  real_T angularPosition_i;            /* '<Root>/MATLAB Function7' */
  real_T angularVelocity_j;            /* '<Root>/MATLAB Function7' */
  real_T pulse_i;                      /* '<Root>/MATLAB Function6' */
  real_T angularPosition_c;            /* '<Root>/MATLAB Function6' */
  real_T angularVelocity_k;            /* '<Root>/MATLAB Function6' */
  real_T pulse_nq;                     /* '<Root>/MATLAB Function11' */
  real_T angularPosition_h;            /* '<Root>/MATLAB Function11' */
  real_T angularVelocity_kl;           /* '<Root>/MATLAB Function11' */
  real_T pulse_p;                      /* '<Root>/MATLAB Function10' */
  real_T angularPosition_cf;           /* '<Root>/MATLAB Function10' */
  real_T angularVelocity_h;            /* '<Root>/MATLAB Function10' */
  uint32_T Raw_x4;                     /* '<Root>/Encoder5' */
  uint32_T Raw_x2;                     /* '<Root>/Encoder4' */
  uint32_T Raw_x1;                     /* '<Root>/Encoder3' */
  boolean_T DigitalPortRead;           /* '<S18>/Digital Port Read' */
  boolean_T DigitalPortRead_i;         /* '<S16>/Digital Port Read' */
  B_DigitalPortRead_QEI_READ_T DigitalPortRead_g;/* '<S20>/Digital Port Read' */
  B_DigitalPortRead_QEI_READ_T DigitalPortRead_k;/* '<S20>/Digital Port Read' */
} B_QEI_READ_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  stm32cube_blocks_EncoderBlock_T obj; /* '<Root>/Encoder5' */
  stm32cube_blocks_EncoderBlock_T obj_n;/* '<Root>/Encoder4' */
  stm32cube_blocks_EncoderBlock_T obj_nl;/* '<Root>/Encoder3' */
  real_T previousCount;                /* '<Root>/MATLAB Function9' */
  real_T homepos;                      /* '<Root>/MATLAB Function9' */
  real_T previousRadians;              /* '<Root>/MATLAB Function9' */
  real_T previousCount_n;              /* '<Root>/MATLAB Function8' */
  real_T totalCount_b;                 /* '<Root>/MATLAB Function8' */
  real_T previousRadians_g;            /* '<Root>/MATLAB Function8' */
  real_T homepos_b;                    /* '<Root>/MATLAB Function8' */
  real_T previousCount_m;              /* '<Root>/MATLAB Function7' */
  real_T totalCount_e;                 /* '<Root>/MATLAB Function7' */
  real_T previousRadians_e;            /* '<Root>/MATLAB Function7' */
  real_T homepos_j;                    /* '<Root>/MATLAB Function7' */
  real_T previousCount_p;              /* '<Root>/MATLAB Function6' */
  real_T totalCount_bt;                /* '<Root>/MATLAB Function6' */
  real_T previousRadians_a;            /* '<Root>/MATLAB Function6' */
  real_T homepos_j3;                   /* '<Root>/MATLAB Function6' */
  real_T previousCount_ns;             /* '<Root>/MATLAB Function11' */
  real_T homepos_h;                    /* '<Root>/MATLAB Function11' */
  real_T previousRadians_m;            /* '<Root>/MATLAB Function11' */
  real_T previousCount_c;              /* '<Root>/MATLAB Function10' */
  real_T homepos_k;                    /* '<Root>/MATLAB Function10' */
  real_T previousRadians_p;            /* '<Root>/MATLAB Function10' */
  boolean_T DelayInput1_DSTATE;        /* '<S2>/Delay Input1' */
  boolean_T DelayInput1_DSTATE_c;      /* '<S1>/Delay Input1' */
  boolean_T previousCount_not_empty_o; /* '<Root>/MATLAB Function8' */
  boolean_T previousCount_not_empty_m; /* '<Root>/MATLAB Function7' */
  boolean_T previousCount_not_empty_l; /* '<Root>/MATLAB Function6' */
  DW_DigitalPortRead_QEI_READ_T DigitalPortRead_g;/* '<S20>/Digital Port Read' */
  DW_DigitalPortRead_QEI_READ_T DigitalPortRead_k;/* '<S20>/Digital Port Read' */
} DW_QEI_READ_T;

/* Real-time Model Data Structure */
struct tag_RTM_QEI_READ_T {
  const char_T *errorStatus;
  RTWExtModeInfo *extModeInfo;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    uint32_T checksums[4];
  } Sizes;

  /*
   * SpecialInfo:
   * The following substructure contains special information
   * related to other components that are dependent on RTW.
   */
  struct {
    const void *mappingInfo;
  } SpecialInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T taskTime0;
    uint32_T clockTick0;
    time_T stepSize0;
    time_T tFinal;
    boolean_T stopRequestedFlag;
  } Timing;
};

/* Block signals (default storage) */
extern B_QEI_READ_T QEI_READ_B;

/* Block states (default storage) */
extern DW_QEI_READ_T QEI_READ_DW;

/* Model entry point functions */
extern void QEI_READ_initialize(void);
extern void QEI_READ_step(void);
extern void QEI_READ_terminate(void);

/* Real-time Model object */
extern RT_MODEL_QEI_READ_T *const QEI_READ_M;
extern volatile boolean_T stopRequested;
extern volatile boolean_T runModel;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'QEI_READ'
 * '<S1>'   : 'QEI_READ/Detect Rise Positive1'
 * '<S2>'   : 'QEI_READ/Detect Rise Positive3'
 * '<S3>'   : 'QEI_READ/Digital Port Read3'
 * '<S4>'   : 'QEI_READ/Digital Port Read5'
 * '<S5>'   : 'QEI_READ/Digital Port Read6'
 * '<S6>'   : 'QEI_READ/Digital Port Read7'
 * '<S7>'   : 'QEI_READ/MATLAB Function10'
 * '<S8>'   : 'QEI_READ/MATLAB Function11'
 * '<S9>'   : 'QEI_READ/MATLAB Function6'
 * '<S10>'  : 'QEI_READ/MATLAB Function7'
 * '<S11>'  : 'QEI_READ/MATLAB Function8'
 * '<S12>'  : 'QEI_READ/MATLAB Function9'
 * '<S13>'  : 'QEI_READ/Detect Rise Positive1/Positive'
 * '<S14>'  : 'QEI_READ/Detect Rise Positive3/Positive'
 * '<S15>'  : 'QEI_READ/Digital Port Read3/ECSoC'
 * '<S16>'  : 'QEI_READ/Digital Port Read3/ECSoC/ECSimCodegen'
 * '<S17>'  : 'QEI_READ/Digital Port Read5/ECSoC'
 * '<S18>'  : 'QEI_READ/Digital Port Read5/ECSoC/ECSimCodegen'
 * '<S19>'  : 'QEI_READ/Digital Port Read6/ECSoC'
 * '<S20>'  : 'QEI_READ/Digital Port Read6/ECSoC/ECSimCodegen'
 * '<S21>'  : 'QEI_READ/Digital Port Read7/ECSoC'
 * '<S22>'  : 'QEI_READ/Digital Port Read7/ECSoC/ECSimCodegen'
 */
#endif                                 /* QEI_READ_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
