/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: QEI_READ.c
 *
 * Code generated for Simulink model 'QEI_READ'.
 *
 * Model version                  : 1.3
 * Simulink Coder version         : 24.2 (R2024b) 21-Jun-2024
 * C/C++ source code generated on : Fri Nov  1 04:06:52 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "QEI_READ.h"
#include "QEI_READ_types.h"
#include "QEI_READ_private.h"
#include "rtwtypes.h"
#include "stm_timer_ll.h"

/* Block signals (default storage) */
B_QEI_READ_T QEI_READ_B;

/* Block states (default storage) */
DW_QEI_READ_T QEI_READ_DW;

/* Real-time model */
static RT_MODEL_QEI_READ_T QEI_READ_M_;
RT_MODEL_QEI_READ_T *const QEI_READ_M = &QEI_READ_M_;

/* Forward declaration for local functions */
static void QEI_READ_SystemCore_setup_kx(stm32cube_blocks_EncoderBlock_T *obj);
static void QEI_READ_SystemCore_setup(stm32cube_blocks_EncoderBlock_T *obj);
static void QEI_READ_SystemCore_setup_k(stm32cube_blocks_EncoderBlock_T *obj);

/* System initialize for atomic system: */
void QEI_READ_DigitalPortRead_Init(DW_DigitalPortRead_QEI_READ_T *localDW)
{
  /* Start for MATLABSystem: '<S20>/Digital Port Read' */
  localDW->objisempty = true;
  localDW->obj.isInitialized = 1;
}

/* Output and update for atomic system: */
void QEI_READ_DigitalPortRead(B_DigitalPortRead_QEI_READ_T *localB)
{
  uint32_T pinReadLoc;

  /* MATLABSystem: '<S20>/Digital Port Read' */
  pinReadLoc = LL_GPIO_ReadInputPort(GPIOC);

  /* MATLABSystem: '<S20>/Digital Port Read' */
  localB->DigitalPortRead = ((pinReadLoc & 8192U) != 0U);
}

static void QEI_READ_SystemCore_setup_kx(stm32cube_blocks_EncoderBlock_T *obj)
{
  uint8_T ChannelInfo;
  TIM_Type_T b;
  boolean_T isSlaveModeTriggerEnabled;

  /* Start for MATLABSystem: '<Root>/Encoder5' */
  obj->isInitialized = 1;
  b.PeripheralPtr = TIM8;
  b.isCenterAlignedMode = false;

  /* Start for MATLABSystem: '<Root>/Encoder5' */
  b.repetitionCounter = 0U;
  obj->TimerHandle = Timer_Handle_Init(&b);
  enableTimerInterrupts(obj->TimerHandle, 0);
  ChannelInfo = ENABLE_CH;

  /* Start for MATLABSystem: '<Root>/Encoder5' */
  enableTimerChannel1(obj->TimerHandle, ChannelInfo);
  enableTimerChannel2(obj->TimerHandle, ChannelInfo);
  isSlaveModeTriggerEnabled = isSlaveTriggerModeEnabled(obj->TimerHandle);
  if (!isSlaveModeTriggerEnabled) {
    /* Start for MATLABSystem: '<Root>/Encoder5' */
    enableCounter(obj->TimerHandle, false);
  }

  obj->isSetupComplete = true;
}

static void QEI_READ_SystemCore_setup(stm32cube_blocks_EncoderBlock_T *obj)
{
  uint8_T ChannelInfo;
  TIM_Type_T b;
  boolean_T isSlaveModeTriggerEnabled;

  /* Start for MATLABSystem: '<Root>/Encoder3' */
  obj->isInitialized = 1;
  b.PeripheralPtr = TIM3;
  b.isCenterAlignedMode = false;

  /* Start for MATLABSystem: '<Root>/Encoder3' */
  b.repetitionCounter = 0U;
  obj->TimerHandle = Timer_Handle_Init(&b);
  enableTimerInterrupts(obj->TimerHandle, 0);
  ChannelInfo = ENABLE_CH;

  /* Start for MATLABSystem: '<Root>/Encoder3' */
  enableTimerChannel1(obj->TimerHandle, ChannelInfo);
  enableTimerChannel2(obj->TimerHandle, ChannelInfo);
  isSlaveModeTriggerEnabled = isSlaveTriggerModeEnabled(obj->TimerHandle);
  if (!isSlaveModeTriggerEnabled) {
    /* Start for MATLABSystem: '<Root>/Encoder3' */
    enableCounter(obj->TimerHandle, false);
  }

  obj->isSetupComplete = true;
}

static void QEI_READ_SystemCore_setup_k(stm32cube_blocks_EncoderBlock_T *obj)
{
  uint8_T ChannelInfo;
  TIM_Type_T b;
  boolean_T isSlaveModeTriggerEnabled;

  /* Start for MATLABSystem: '<Root>/Encoder4' */
  obj->isInitialized = 1;
  b.PeripheralPtr = TIM4;
  b.isCenterAlignedMode = false;

  /* Start for MATLABSystem: '<Root>/Encoder4' */
  b.repetitionCounter = 0U;
  obj->TimerHandle = Timer_Handle_Init(&b);
  enableTimerInterrupts(obj->TimerHandle, 0);
  ChannelInfo = ENABLE_CH;

  /* Start for MATLABSystem: '<Root>/Encoder4' */
  enableTimerChannel1(obj->TimerHandle, ChannelInfo);
  enableTimerChannel2(obj->TimerHandle, ChannelInfo);
  isSlaveModeTriggerEnabled = isSlaveTriggerModeEnabled(obj->TimerHandle);
  if (!isSlaveModeTriggerEnabled) {
    /* Start for MATLABSystem: '<Root>/Encoder4' */
    enableCounter(obj->TimerHandle, false);
  }

  obj->isSetupComplete = true;
}

/* Model step function */
void QEI_READ_step(void)
{
  real_T diffCount;
  uint32_T pinReadLoc;
  boolean_T rtb_FixPtRelationalOperator;
  boolean_T tmp;

  /* MATLABSystem: '<S16>/Digital Port Read' */
  pinReadLoc = LL_GPIO_ReadInputPort(GPIOB);

  /* MATLABSystem: '<S16>/Digital Port Read' */
  QEI_READ_B.DigitalPortRead_i = ((pinReadLoc & 1024U) != 0U);

  /* DataTypeConversion: '<Root>/Cast To Double5' */
  QEI_READ_B.CastToDouble5 = QEI_READ_B.DigitalPortRead_i;

  /* MATLABSystem: '<S18>/Digital Port Read' */
  pinReadLoc = LL_GPIO_ReadInputPort(GPIOB);

  /* MATLABSystem: '<S18>/Digital Port Read' */
  QEI_READ_B.DigitalPortRead = ((pinReadLoc & 16U) != 0U);
  QEI_READ_DigitalPortRead(&QEI_READ_B.DigitalPortRead_g);

  /* RelationalOperator: '<S2>/FixPt Relational Operator' incorporates:
   *  RelationalOperator: '<S14>/Compare'
   *  UnitDelay: '<S2>/Delay Input1'
   *
   * Block description for '<S2>/Delay Input1':
   *
   *  Store in Global RAM
   */
  rtb_FixPtRelationalOperator = ((int32_T)
    QEI_READ_B.DigitalPortRead_g.DigitalPortRead > (int32_T)
    QEI_READ_DW.DelayInput1_DSTATE);

  /* MATLAB Function: '<Root>/MATLAB Function10' incorporates:
   *  DataTypeConversion: '<Root>/Cast To Double6'
   *  MATLAB Function: '<Root>/MATLAB Function11'
   *  MATLAB Function: '<Root>/MATLAB Function9'
   */
  tmp = !QEI_READ_B.DigitalPortRead;
  if ((QEI_READ_B.CastToDouble5 == 1.0) && tmp) {
    QEI_READ_DW.previousCount_c += 2.0;
  } else if ((QEI_READ_B.CastToDouble5 == 0.0) && QEI_READ_B.DigitalPortRead) {
    QEI_READ_DW.previousCount_c -= 2.0;
  }

  if (rtb_FixPtRelationalOperator) {
    QEI_READ_DW.homepos_k = QEI_READ_DW.previousCount_c;
  }

  QEI_READ_B.pulse_p = QEI_READ_DW.previousCount_c - QEI_READ_DW.homepos_k;
  QEI_READ_B.angularPosition_cf = QEI_READ_B.pulse_p / 2048.0 * 2.0 *
    3.1415926535897931;
  QEI_READ_B.angularVelocity_h = (QEI_READ_B.angularPosition_cf -
    QEI_READ_DW.previousRadians_p) / 0.1;
  QEI_READ_DW.previousRadians_p = QEI_READ_B.angularPosition_cf;

  /* End of MATLAB Function: '<Root>/MATLAB Function10' */
  /* MATLAB Function: '<Root>/MATLAB Function9' incorporates:
   *  DataTypeConversion: '<Root>/Cast To Double6'
   */
  if ((QEI_READ_B.CastToDouble5 == 1.0) && tmp) {
    QEI_READ_DW.previousCount++;
  } else if ((QEI_READ_B.CastToDouble5 == 0.0) && QEI_READ_B.DigitalPortRead) {
    QEI_READ_DW.previousCount--;
  }

  if (rtb_FixPtRelationalOperator) {
    QEI_READ_DW.homepos = QEI_READ_DW.previousCount;
  }

  QEI_READ_B.pulse = QEI_READ_DW.previousCount - QEI_READ_DW.homepos;
  QEI_READ_B.angularPosition = QEI_READ_B.pulse / 2048.0 * 2.0 *
    3.1415926535897931;
  QEI_READ_B.angularVelocity = (QEI_READ_B.angularPosition -
    QEI_READ_DW.previousRadians) / 0.1;
  QEI_READ_DW.previousRadians = QEI_READ_B.angularPosition;

  /* MATLAB Function: '<Root>/MATLAB Function11' incorporates:
   *  DataTypeConversion: '<Root>/Cast To Double6'
   */
  if ((QEI_READ_B.CastToDouble5 == 1.0) && tmp) {
    QEI_READ_DW.previousCount_ns += 4.0;
  } else if ((QEI_READ_B.CastToDouble5 == 0.0) && QEI_READ_B.DigitalPortRead) {
    QEI_READ_DW.previousCount_ns -= 4.0;
  }

  if (rtb_FixPtRelationalOperator) {
    QEI_READ_DW.homepos_h = QEI_READ_DW.previousCount_ns;
  }

  QEI_READ_B.pulse_nq = QEI_READ_DW.previousCount_ns - QEI_READ_DW.homepos_h;
  QEI_READ_B.angularPosition_h = QEI_READ_B.pulse_nq / 2048.0 * 2.0 *
    3.1415926535897931;
  QEI_READ_B.angularVelocity_kl = (QEI_READ_B.angularPosition_h -
    QEI_READ_DW.previousRadians_m) / 0.1;
  QEI_READ_DW.previousRadians_m = QEI_READ_B.angularPosition_h;
  QEI_READ_DigitalPortRead(&QEI_READ_B.DigitalPortRead_k);

  /* RelationalOperator: '<S1>/FixPt Relational Operator' incorporates:
   *  RelationalOperator: '<S13>/Compare'
   *  UnitDelay: '<S1>/Delay Input1'
   *
   * Block description for '<S1>/Delay Input1':
   *
   *  Store in Global RAM
   */
  rtb_FixPtRelationalOperator = ((int32_T)
    QEI_READ_B.DigitalPortRead_k.DigitalPortRead > (int32_T)
    QEI_READ_DW.DelayInput1_DSTATE_c);

  /* MATLABSystem: '<Root>/Encoder5' */
  QEI_READ_B.Raw_x4 = getTimerCounterValueForG4(QEI_READ_DW.obj.TimerHandle,
    false, NULL);

  /* MATLAB Function: '<Root>/MATLAB Function8' incorporates:
   *  DataTypeConversion: '<Root>/Cast To Double9'
   */
  if (!QEI_READ_DW.previousCount_not_empty_o) {
    QEI_READ_DW.previousCount_n = QEI_READ_B.Raw_x4;
    QEI_READ_DW.previousCount_not_empty_o = true;
  }

  diffCount = (real_T)QEI_READ_B.Raw_x4 - QEI_READ_DW.previousCount_n;
  if (diffCount < -32767.0) {
    QEI_READ_DW.totalCount_b += diffCount + 65534.0;
  } else if (diffCount > 32767.0) {
    QEI_READ_DW.totalCount_b += diffCount - 65534.0;
  } else {
    QEI_READ_DW.totalCount_b += diffCount;
  }

  if (rtb_FixPtRelationalOperator) {
    QEI_READ_DW.homepos_b = QEI_READ_DW.totalCount_b;
  }

  QEI_READ_B.pulse_n = QEI_READ_DW.totalCount_b - QEI_READ_DW.homepos_b;
  QEI_READ_B.angularPosition_o = QEI_READ_B.pulse_n / 2048.0 * 2.0 *
    3.1415926535897931;
  QEI_READ_B.angularVelocity_c = (QEI_READ_B.angularPosition_o -
    QEI_READ_DW.previousRadians_g) / 0.1;
  QEI_READ_DW.previousCount_n = QEI_READ_B.Raw_x4;
  QEI_READ_DW.previousRadians_g = QEI_READ_B.angularPosition_o;

  /* End of MATLAB Function: '<Root>/MATLAB Function8' */
  /* MATLABSystem: '<Root>/Encoder3' */
  QEI_READ_B.Raw_x1 = getTimerCounterValueForG4(QEI_READ_DW.obj_nl.TimerHandle,
    false, NULL);

  /* MATLAB Function: '<Root>/MATLAB Function6' incorporates:
   *  DataTypeConversion: '<Root>/Cast To Double7'
   */
  if (!QEI_READ_DW.previousCount_not_empty_l) {
    QEI_READ_DW.previousCount_p = QEI_READ_B.Raw_x1;
    QEI_READ_DW.previousCount_not_empty_l = true;
  }

  diffCount = (real_T)QEI_READ_B.Raw_x1 - QEI_READ_DW.previousCount_p;
  if (diffCount < -32767.0) {
    QEI_READ_DW.totalCount_bt += diffCount + 65534.0;
  } else if (diffCount > 32767.0) {
    QEI_READ_DW.totalCount_bt += diffCount - 65534.0;
  } else {
    QEI_READ_DW.totalCount_bt += diffCount;
  }

  if (rtb_FixPtRelationalOperator) {
    QEI_READ_DW.homepos_j3 = QEI_READ_DW.totalCount_bt;
  }

  QEI_READ_B.pulse_i = QEI_READ_DW.totalCount_bt - QEI_READ_DW.homepos_j3;
  QEI_READ_B.angularPosition_c = QEI_READ_B.pulse_i / 2048.0 * 2.0 *
    3.1415926535897931;
  QEI_READ_B.angularVelocity_k = (QEI_READ_B.angularPosition_c -
    QEI_READ_DW.previousRadians_a) / 0.1;
  QEI_READ_DW.previousCount_p = QEI_READ_B.Raw_x1;
  QEI_READ_DW.previousRadians_a = QEI_READ_B.angularPosition_c;

  /* End of MATLAB Function: '<Root>/MATLAB Function6' */
  /* MATLABSystem: '<Root>/Encoder4' */
  QEI_READ_B.Raw_x2 = getTimerCounterValueForG4(QEI_READ_DW.obj_n.TimerHandle,
    false, NULL);

  /* MATLAB Function: '<Root>/MATLAB Function7' incorporates:
   *  DataTypeConversion: '<Root>/Cast To Double8'
   */
  if (!QEI_READ_DW.previousCount_not_empty_m) {
    QEI_READ_DW.previousCount_m = QEI_READ_B.Raw_x2;
    QEI_READ_DW.previousCount_not_empty_m = true;
  }

  diffCount = (real_T)QEI_READ_B.Raw_x2 - QEI_READ_DW.previousCount_m;
  if (diffCount < -32767.0) {
    QEI_READ_DW.totalCount_e += diffCount + 65534.0;
  } else if (diffCount > 32767.0) {
    QEI_READ_DW.totalCount_e += diffCount - 65534.0;
  } else {
    QEI_READ_DW.totalCount_e += diffCount;
  }

  if (rtb_FixPtRelationalOperator) {
    QEI_READ_DW.homepos_j = QEI_READ_DW.totalCount_e;
  }

  QEI_READ_B.pulse_c = QEI_READ_DW.totalCount_e - QEI_READ_DW.homepos_j;
  QEI_READ_B.angularPosition_i = QEI_READ_B.pulse_c / 2048.0 * 2.0 *
    3.1415926535897931;
  QEI_READ_B.angularVelocity_j = (QEI_READ_B.angularPosition_i -
    QEI_READ_DW.previousRadians_e) / 0.1;
  QEI_READ_DW.previousCount_m = QEI_READ_B.Raw_x2;
  QEI_READ_DW.previousRadians_e = QEI_READ_B.angularPosition_i;

  /* End of MATLAB Function: '<Root>/MATLAB Function7' */
  /* Update for UnitDelay: '<S2>/Delay Input1' incorporates:
   *  RelationalOperator: '<S14>/Compare'
   *
   * Block description for '<S2>/Delay Input1':
   *
   *  Store in Global RAM
   */
  QEI_READ_DW.DelayInput1_DSTATE = QEI_READ_B.DigitalPortRead_g.DigitalPortRead;

  /* Update for UnitDelay: '<S1>/Delay Input1' incorporates:
   *  RelationalOperator: '<S13>/Compare'
   *
   * Block description for '<S1>/Delay Input1':
   *
   *  Store in Global RAM
   */
  QEI_READ_DW.DelayInput1_DSTATE_c =
    QEI_READ_B.DigitalPortRead_k.DigitalPortRead;

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   */
  QEI_READ_M->Timing.taskTime0 =
    ((time_T)(++QEI_READ_M->Timing.clockTick0)) * QEI_READ_M->Timing.stepSize0;
}

/* Model initialize function */
void QEI_READ_initialize(void)
{
  /* Registration code */
  rtmSetTFinal(QEI_READ_M, -1);
  QEI_READ_M->Timing.stepSize0 = 0.1;

  /* External mode info */
  QEI_READ_M->Sizes.checksums[0] = (625948037U);
  QEI_READ_M->Sizes.checksums[1] = (2619951298U);
  QEI_READ_M->Sizes.checksums[2] = (3843013079U);
  QEI_READ_M->Sizes.checksums[3] = (4114123175U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[14];
    QEI_READ_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = &rtAlwaysEnabled;
    systemRan[2] = &rtAlwaysEnabled;
    systemRan[3] = &rtAlwaysEnabled;
    systemRan[4] = &rtAlwaysEnabled;
    systemRan[5] = &rtAlwaysEnabled;
    systemRan[6] = &rtAlwaysEnabled;
    systemRan[7] = &rtAlwaysEnabled;
    systemRan[8] = &rtAlwaysEnabled;
    systemRan[9] = &rtAlwaysEnabled;
    systemRan[10] = &rtAlwaysEnabled;
    systemRan[11] = &rtAlwaysEnabled;
    systemRan[12] = &rtAlwaysEnabled;
    systemRan[13] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(QEI_READ_M->extModeInfo,
      &QEI_READ_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(QEI_READ_M->extModeInfo, QEI_READ_M->Sizes.checksums);
    rteiSetTPtr(QEI_READ_M->extModeInfo, rtmGetTPtr(QEI_READ_M));
  }

  QEI_READ_DigitalPortRead_Init(&QEI_READ_DW.DigitalPortRead_g);
  QEI_READ_DigitalPortRead_Init(&QEI_READ_DW.DigitalPortRead_k);

  /* Start for MATLABSystem: '<Root>/Encoder5' */
  QEI_READ_DW.obj.isInitialized = 0;
  QEI_READ_DW.obj.matlabCodegenIsDeleted = false;
  QEI_READ_SystemCore_setup_kx(&QEI_READ_DW.obj);

  /* Start for MATLABSystem: '<Root>/Encoder3' */
  QEI_READ_DW.obj_nl.isInitialized = 0;
  QEI_READ_DW.obj_nl.matlabCodegenIsDeleted = false;
  QEI_READ_SystemCore_setup(&QEI_READ_DW.obj_nl);

  /* Start for MATLABSystem: '<Root>/Encoder4' */
  QEI_READ_DW.obj_n.isInitialized = 0;
  QEI_READ_DW.obj_n.matlabCodegenIsDeleted = false;
  QEI_READ_SystemCore_setup_k(&QEI_READ_DW.obj_n);
}

/* Model terminate function */
void QEI_READ_terminate(void)
{
  uint8_T ChannelInfo;

  /* Terminate for MATLABSystem: '<Root>/Encoder5' */
  if (!QEI_READ_DW.obj.matlabCodegenIsDeleted) {
    QEI_READ_DW.obj.matlabCodegenIsDeleted = true;
    if ((QEI_READ_DW.obj.isInitialized == 1) && QEI_READ_DW.obj.isSetupComplete)
    {
      disableCounter(QEI_READ_DW.obj.TimerHandle);
      disableTimerInterrupts(QEI_READ_DW.obj.TimerHandle, 0);
      ChannelInfo = ENABLE_CH;
      disableTimerChannel1(QEI_READ_DW.obj.TimerHandle, ChannelInfo);
      disableTimerChannel2(QEI_READ_DW.obj.TimerHandle, ChannelInfo);
    }
  }

  /* End of Terminate for MATLABSystem: '<Root>/Encoder5' */
  /* Terminate for MATLABSystem: '<Root>/Encoder3' */
  if (!QEI_READ_DW.obj_nl.matlabCodegenIsDeleted) {
    QEI_READ_DW.obj_nl.matlabCodegenIsDeleted = true;
    if ((QEI_READ_DW.obj_nl.isInitialized == 1) &&
        QEI_READ_DW.obj_nl.isSetupComplete) {
      disableCounter(QEI_READ_DW.obj_nl.TimerHandle);
      disableTimerInterrupts(QEI_READ_DW.obj_nl.TimerHandle, 0);
      ChannelInfo = ENABLE_CH;
      disableTimerChannel1(QEI_READ_DW.obj_nl.TimerHandle, ChannelInfo);
      disableTimerChannel2(QEI_READ_DW.obj_nl.TimerHandle, ChannelInfo);
    }
  }

  /* End of Terminate for MATLABSystem: '<Root>/Encoder3' */
  /* Terminate for MATLABSystem: '<Root>/Encoder4' */
  if (!QEI_READ_DW.obj_n.matlabCodegenIsDeleted) {
    QEI_READ_DW.obj_n.matlabCodegenIsDeleted = true;
    if ((QEI_READ_DW.obj_n.isInitialized == 1) &&
        QEI_READ_DW.obj_n.isSetupComplete) {
      disableCounter(QEI_READ_DW.obj_n.TimerHandle);
      disableTimerInterrupts(QEI_READ_DW.obj_n.TimerHandle, 0);
      ChannelInfo = ENABLE_CH;
      disableTimerChannel1(QEI_READ_DW.obj_n.TimerHandle, ChannelInfo);
      disableTimerChannel2(QEI_READ_DW.obj_n.TimerHandle, ChannelInfo);
    }
  }

  /* End of Terminate for MATLABSystem: '<Root>/Encoder4' */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
