Vonshield = [3.2794, 3.2799, 2.412, 1.9968, 1.832, 1.7671, 1.7527];
Vwithshield = [3.2802, 2.9673, 2.1991, 1.9258, 1.8127, 1.7509, 1.7243]; 
Distance = 0:0.5:3;

figure;           
plot(Distance, Vwithshield , 'r-', 'LineWidth', 1.5); 
hold on; 
grid on;

%title('แรงดันขาออกของ DRV5055');     
%xlabel('ระยะห่าง (cm)');                   
%ylabel('แรงดันขาออก (V)');

title('แรงดันขาออกของ DRV5055 เมื่อมี shield');     
xlabel('ระยะห่าง (cm)');                   
ylabel('แรงดันขาออก (V)');