

R = rotm2d(0.3);
